var express = require('express');
var app = express();
var http = require('http').Server(app);
var io = require('socket.io')(http);
const path = require('path');
var fs = require('fs');
var bp = require('body-parser').urlencoded({ extended: false })
var mysql = require('mysql');

app.use(express.static('./'));
var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "Ankan@123",
  database: "ankan"
});

app.get('/main', (req, res) => {
   res.sendFile(__dirname+'/index.html');
});

app.get('/login/', (req, res) => {
   res.sendFile(__dirname+'/login/index.html');
});

app.get('/register/', (req, res) =>{
   res.sendFile(__dirname+'/register/index.html');
});

loggers = [];
app.post('/logData/', bp, (req, res) => {
   response = {
      name:req.body.username,
      pass:req.body.pass
   };
   var resu = "";
    var sql = "SELECT * FROM register_tab WHERE Name = '"+response.name+"' and Password = '"+response.pass+"'";
   con.query(sql,  (err, result, fields) => {
    if (err) throw err;
    if (result.length != 0){
    	resu = result[0].Name;
    	console.log(resu);
    	loggers.push(resu);
    }
    else{
    	console.log("no user");
    }
  });
   res.send()
});

app.post('/regData/', bp, (req, res) => {
	response = {
      name:req.body.name,
      dob:req.body.birthday,
      email:req.body.email,
      pass:req.body.passwd,
      passc:req.body.passwd_confirm,
   };
   console.log(response);
   if (response.pass != response.passc){
   	res.send("password doesn't match. Please try again.............");
   }
   else{
   	con.connect((err) => {
  	if (err) throw err;
  	console.log("Connected!");
 	var sql = "INSERT INTO register_tab (Name, Password, Email, DOB) VALUES ('"+response.name+"','"+response.pass+"','"+response.email+"','"+response.dob+"')";
 	con.query(sql, (err, result) => {
    if (err) throw err;
    console.log("1 record inserted");
  });
});
   	res.end("<html><body>Registration done. Please <a href='http://localhost:3000/login/'>Click here</a> to get to login page</body></html>");
   }
});

app.listen(8080, function(){
	console.log("listening on port 8080.........");
});